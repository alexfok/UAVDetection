# UAV Detection — UI/UX handoff for Codex

This folder is the design spec for streamlining the UAV Detection web app
(`web/annotator/` served by `scripts/annotation_server.py`).

## Contents
- `UAV-Detection-UI-mockup.html` — self-contained, offline mockup of the target UI.
  Open in a browser. Resize the window to see the responsive breakpoints. Click the
  Live/Advanced toggle, the Panels chips, the camera chips, and Start/Stop to see states.
- `IMPLEMENTATION_NOTES.md` — the written spec: tokens, the Live/Advanced split,
  toggleable panels + persistence, the 2/3 center layout + responsive breakpoints, and
  the multi-camera preview grid. **Read this first.**
- `screenshots/` — desktop, tablet, mobile references.

## Suggested Codex prompt

> Implement the UI changes described in `IMPLEMENTATION_NOTES.md` in `web/annotator/`
> (`index.html`, `styles.css`, `app.js`). Use `UAV-Detection-UI-mockup.html` and the
> screenshots as the visual reference. Keep the existing dark theme and design tokens.
> Preserve all current backend calls and behavior — this is a presentation-layer change.
> Specifically: (1) split Live Detection into Live (minimal) and Advanced (full controls),
> (2) make Media / Controls / Status / Events panels toggleable and persist the layout to
> localStorage, (3) fold Diagnostics into the right-hand Live Events feed, (4) center stage
> ~2/3 width with side panels sharing the rest, (5) support selecting multiple cameras and
> show an adaptive preview grid, (6) make it responsive for mobile / tablet / laptop.

## Notes for the implementer
- The mockup uses inline styles + a JS resize listener only because of the prototyping
  environment. In the real app, prefer CSS classes + media queries (the notes give the
  exact breakpoints and grid math).
- All data in the mockup is placeholder — wire panels, previews, and events to the
  existing endpoints.
