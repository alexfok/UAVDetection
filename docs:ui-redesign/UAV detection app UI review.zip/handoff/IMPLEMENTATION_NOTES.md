# UAV Detection — UI/UX streamline: implementation notes

These notes describe the changes prototyped in `UAV Detection UI.dc.html` so they can be
re-implemented in the real frontend (`web/annotator/index.html`, `styles.css`, `app.js`).
The prototype **reuses the existing dark palette verbatim** — no new design system.

## Design tokens (unchanged, from `styles.css`)
`--bg #111315` · `--panel #1a1d20` · `--panel-2 #22262a` · `--line #343a40`
`--text #f3f5f7` · `--muted #a8b0b8` · `--accent #30bced` · `--danger #f25f5c` · `--good #46d369`
Font: Inter. Buttons 36px / radius 6px. Primary button: border `--accent`, bg `#0d4b60`.

## 1. Live Detection → Live vs Advanced split
Add a mode segmented control in the Live tab header: **Live** (default) and **Advanced**.
Persist choice (see §3).

- **Advanced** = the *current* full `#liveTab` toolbar (camera sources, stream, source,
  conf, preview/detect FPS, skip, preset, img size, preview size, quality, device,
  record, labels). Unchanged behavior.
- **Live** (minimal) = only: **camera/source selector**, **Conf** (read-only chip or compact
  input), **Record** toggle, **Snapshot**, **Fullscreen**, and **Start/Stop**.
  Everything else stays in Advanced. The minimal set was chosen with the operator; all
  hidden fields keep their last Advanced values — Live view only changes what is *shown*,
  never the underlying detection params.

Suggested state: `liveMode: 'live' | 'advanced'`. In `live` mode, hide the advanced
field group and render the minimal strip. Start/Stop is shared by both.

## 2. Toggleable layout panels
Add a "Panels" chip group on the right of the top tab bar. Four independent toggles:
- **Media** → left media-folder `<aside class="mediaPanel">`
- **Controls** → the tab's header toolbar (`.topbar` for the active tab)
- **Status** → the status/stats bar (see §4)
- **Events** → right `<aside class="eventsPanel">`

Each chip: active = accent border + filled dot; inactive = muted/dim. Clicking toggles
`display` of the target region **and** recomputes the workspace grid.

### Grid gotcha (important)
`.workspace` is `grid-template-columns: <left> 1fr <right>`. When a side panel is hidden,
**remove its column track**, don't set it to `0px`, and remove the panel node from the DOM
(or the single remaining child lands in the wrong track). Build the template string from
only the visible panels:
```js
const cols = [];
if (show.media) cols.push('minmax(260px,300px)');
cols.push('minmax(0,1fr)');
if (show.events) cols.push('minmax(300px,340px)');
workspace.style.gridTemplateColumns = cols.join(' ');
```

## 3. Persistence
Persist `{ activeTab, liveMode, show:{media,controls,events,status} }` to
`localStorage['uavUiLayout']`; restore on load. Fall back to all-visible / `live` mode
when absent or unparseable.

## 4. Status / stats bar (new, optional but recommended)
A thin bar under the control bar showing live telemetry: state dot + label, FPS, detect
Hz, latency, active tracks, source string. Toggled by the **Status** chip. Values come from
the existing live-detection status feed (`liveStatus`, FPS from the stream metadata).

## 5. Layout proportions & responsive behavior
Viewport-driven (JS `resize` listener → `vw` state → `layout`), since inline styles can't
use media queries. Breakpoints: **mobile <760px**, **tablet 760–1179px**, **desktop ≥1180px**.

- **Desktop / tablet**: 3-column CSS grid. Center stage ≈ **2/3** width via
  `grid-template-columns: minmax(<side>,1fr) minmax(0,4fr) minmax(<side>,1fr)`
  (4:1:1 → center 4/6). Side min is 230px desktop / 190px tablet. Hidden panels drop
  their track (see §2 grid gotcha) so the center grows.
- **Mobile**: switch container to `display:flex; flex-direction:column; overflow:auto`.
  Order: previews (center) → events → media folder. Side panels become full-width with
  `max-height:66vh` + internal scroll; stage gets `min-height:54vh`. The "Panels" label
  hides; toggle chips remain.

In the real app you can implement the same with CSS media queries + classes instead of a
JS listener — the prototype uses JS only because DC styling is inline.

## 6. Multi-camera preview grid (Live)
Cameras are selectable (chips in Live minimal controls; chip group in Advanced). Each
selected camera renders a preview tile in the center. Grid columns by count (desktop):
1→1 col (centered, max-width 1100), 2–4→2 cols, 5+→3 cols; mobile always 1 col. Each tile:
16:9, camera-label chip (top-left), LIVE badge (top-right, only while running), detection
overlay boxes, and a dimmed "STOPPED" state when idle. Status bar shows the active
**Cameras** count. Wire tiles to the real per-camera MJPEG/WebRTC preview streams and the
per-camera detection results.

## 7. Notes
- The center stage always renders regardless of which side panels are visible.
- Fullscreen should target the live viewer element, not the whole document, so controls
  can overlay it later if desired.
- Snapshot in the prototype is a brightness flash placeholder — wire to the existing
  frame-capture/record endpoint.
